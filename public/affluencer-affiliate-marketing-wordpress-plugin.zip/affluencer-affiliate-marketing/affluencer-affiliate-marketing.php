<?php
/**
 * Plugin Name: Herlan Affluencer Affiliate Marketing
 * Description: External microservice integration for affiliate campaigns & products pivot.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

define('AFFLUENCER_AAM_PATH', plugin_dir_path(__FILE__));

require_once AFFLUENCER_AAM_PATH . 'includes/Autoloader.php';

use AffluencerAAM\Plugin;
use AffluencerAAM\Activator;

AffluencerAAM\Autoloader::register();

register_activation_hook(__FILE__, [Activator::class, 'activate']);

add_action('plugins_loaded', function () {
    (new Plugin())->boot();
});
