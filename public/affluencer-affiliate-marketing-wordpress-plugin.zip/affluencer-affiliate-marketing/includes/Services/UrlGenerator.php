<?php
namespace AffluencerAAM\Services;

if (!defined('ABSPATH')) exit;

class UrlGenerator
{
    /**
     * Woo tag archive URL:
     * /product-tag/{campaign_code}/
     */
    public function campaign_url(string $campaignCode): string
    {
        $slug = sanitize_title($campaignCode);
        return home_url("/product-tag/{$slug}/");
    }
}
