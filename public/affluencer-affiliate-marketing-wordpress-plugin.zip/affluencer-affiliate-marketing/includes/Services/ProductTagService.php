<?php
namespace AffluencerAAM\Services;

if (!defined('ABSPATH')) exit;

class ProductTagService
{
    public function ensureTag(string $slugOrName): int
    {
        $slugOrName = trim($slugOrName);
        if ($slugOrName === '') {
            throw new \InvalidArgumentException('campaign_code is required');
        }

        $slug = sanitize_title($slugOrName);

        $term = get_term_by('slug', $slug, 'product_tag');
        if ($term && !is_wp_error($term)) {
            return (int) $term->term_id;
        }

        $created = wp_insert_term($slugOrName, 'product_tag', ['slug' => $slug]);

        if (is_wp_error($created)) {
            // handle race condition or "already exists"
            $term = get_term_by('slug', $slug, 'product_tag');
            if ($term && !is_wp_error($term)) return (int) $term->term_id;

            throw new \RuntimeException($created->get_error_message());
        }

        return (int) $created['term_id'];
    }

    /**
     * Find parent product ids by sku (supports variations).
     */
    public function productIdsBySku(string $sku): array
    {
        global $wpdb;

        $sku = trim($sku);
        if ($sku === '') return [];

        $sql = "
            SELECT pm.post_id
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE pm.meta_key = '_sku'
              AND pm.meta_value = %s
              AND p.post_type IN ('product','product_variation')
              AND p.post_status IN ('publish','private')
        ";

        $ids = $wpdb->get_col($wpdb->prepare($sql, $sku)) ?: [];

        $final = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            $parent = wp_get_post_parent_id($id);
            $final[] = $parent ? (int) $parent : $id; // tag parent if variation
        }

        return array_values(array_unique(array_filter($final)));
    }

    /**
     * Attach term to products without removing existing tags.
     */
    public function attachTagToProducts(int $termId, array $productIds): array
    {
        $updated = [];
        $missing = [];

        foreach ($productIds as $pid) {
            $pid = (int) $pid;
            if ($pid <= 0) continue;

            if (get_post_type($pid) !== 'product') continue;

            $res = wp_set_object_terms($pid, [$termId], 'product_tag', true);
            if (is_wp_error($res)) {
                $missing[] = $pid;
                continue;
            }

            $updated[] = $pid;
        }

        return ['updated' => $updated, 'failed' => $missing];
    }

    /**
     * Main: campaign_code tag + products[] (sku list)
     */
    public function tagProductsByCampaign(string $campaignCode, array $products): array
    {
        $termId = $this->ensureTag($campaignCode);

        $allProductIds = [];
        $notFoundSkus  = [];

        foreach ($products as $p) {
            $sku = is_array($p)
                ? (string) ($p['sku'] ?? '')
                : (string) $p; // allow ["SKU1","SKU2"] as well

            $sku = sanitize_text_field($sku);
            if ($sku === '') continue;

            $ids = $this->productIdsBySku($sku);
            if (!$ids) {
                $notFoundSkus[] = $sku;
                continue;
            }

            $allProductIds = array_merge($allProductIds, $ids);
        }

        $allProductIds = array_values(array_unique($allProductIds));

        $attach = $this->attachTagToProducts($termId, $allProductIds);

        return [
            'term_id' => $termId,
            'tag_slug' => sanitize_title($campaignCode),
            'product_ids' => $allProductIds,
            'updated' => $attach['updated'],
            'failed' => $attach['failed'],
            'not_found_skus' => array_values(array_unique($notFoundSkus)),
        ];
    }
}
