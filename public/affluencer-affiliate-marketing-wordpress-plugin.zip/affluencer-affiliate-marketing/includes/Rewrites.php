<?php
namespace AffluencerAAM;

class Rewrites {
    public function register(): void {
        add_action('init', [$this, 'add_rewrite_rules']);
        add_action('init', [$this, 'add_query_vars']);
        add_action('template_redirect', [$this, 'handle']);
    }

    public function add_query_vars(): void {
        add_rewrite_tag('%aff_campaign%', '([^&]+)');
    }

    public function add_rewrite_rules(): void {
        add_rewrite_rule(
            '^product-tag/([^/]+)/([^/]+)/?$',
            'index.php?product_tag=$matches[1]&aff_campaign=$matches[2]',
            'top'
        );
    }

    public function handle(): void {
        $code = get_query_var('aff_campaign');
        if (!$code) return;
        setcookie('aff_campaign', sanitize_text_field($code), time()+30*DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN);
    }
}
