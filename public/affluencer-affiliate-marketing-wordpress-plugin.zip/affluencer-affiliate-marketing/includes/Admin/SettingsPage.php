<?php
namespace AffluencerAAM\Admin;

use AffluencerAAM\Activator;

if (!defined('ABSPATH')) exit;

class SettingsPage
{
    public function register(): void
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'registerSettings']);
    }

    public function menu(): void
    {
        add_menu_page(
            'Affluencer Affiliate',
            'Affluencer',
            'manage_options',
            'affluencer-aam',
            [$this, 'render'],
            'dashicons-admin-links'
        );
    }

    public function registerSettings(): void
    {
        register_setting('affluencer_aam_settings', Activator::OPTION_TOKEN, [
            'type' => 'string',
            'sanitize_callback' => function ($value) {
                $value = trim((string) $value);
                return $value === '' ? wp_generate_password(48, true, true) : $value;
            },
            'default' => '',
        ]);
    }

    public function render(): void
    {
        if (!current_user_can('manage_options')) return;

        // Regenerate token action
        if (isset($_POST['affluencer_regenerate_token']) && check_admin_referer('affluencer_regenerate_token_action')) {
            update_option(Activator::OPTION_TOKEN, wp_generate_password(48, true, true));
            echo '<div class="notice notice-success"><p>Token regenerated.</p></div>';
        }

        $token = (string) get_option(Activator::OPTION_TOKEN, '');

        ?>
        <div class="wrap">
            <h1>Affluencer Affiliate Marketing</h1>

            <h2>API Token</h2>
            <p>Use this token in header: <code>X-AFFLUENCER-TOKEN</code></p>

            <form method="post" action="options.php">
                <?php
                settings_fields('affluencer_aam_settings');
                ?>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="affluencer_token">Token</label></th>
                        <td>
                            <input
                                id="affluencer_token"
                                name="<?php echo esc_attr(Activator::OPTION_TOKEN); ?>"
                                type="text"
                                class="regular-text"
                                value="<?php echo esc_attr($token); ?>"
                            />
                            <p class="description">Keep it secret. Change it if compromised.</p>
                        </td>
                    </tr>
                </table>

                <?php submit_button('Save Token'); ?>
            </form>

            <form method="post" style="margin-top: 16px;">
                <?php wp_nonce_field('affluencer_regenerate_token_action'); ?>
                <input type="hidden" name="affluencer_regenerate_token" value="1" />
                <?php submit_button('Regenerate Token', 'secondary'); ?>
            </form>
        </div>
        <?php
    }
}
