<?php
namespace AffluencerAAM;

use AffluencerAAM\Db\Schema;

class Activator {
    const OPTION_TOKEN = 'affluencer_api_token';

    public static function activate(): void {
        (new Schema())->create_tables();
        if (!get_option(self::OPTION_TOKEN)) {
            update_option(self::OPTION_TOKEN, wp_generate_password(48, true, true));
        }
//        (new Rewrites())->add_query_vars();
//        (new Rewrites())->add_rewrite_rules();
//        flush_rewrite_rules();
    }
}
