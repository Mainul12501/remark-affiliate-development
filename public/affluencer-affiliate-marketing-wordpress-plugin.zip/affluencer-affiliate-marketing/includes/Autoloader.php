<?php
namespace AffluencerAAM;

class Autoloader {
    public static function register() {
        spl_autoload_register(function ($class) {
            if (strpos($class, __NAMESPACE__) !== 0) return;
            $path = AFFLUENCER_AAM_PATH . 'includes/' . str_replace(['AffluencerAAM\\', '\\'], ['', '/'], $class) . '.php';
            if (file_exists($path)) require_once $path;
        });
    }
}
