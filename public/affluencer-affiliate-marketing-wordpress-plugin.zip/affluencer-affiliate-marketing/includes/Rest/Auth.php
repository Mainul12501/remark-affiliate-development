<?php
namespace AffluencerAAM\Rest;

use AffluencerAAM\Activator;

if (!defined('ABSPATH')) exit;

class Auth {
    public function allowed(\WP_REST_Request $r): bool {
        $token = (string) $r->get_header('x-affluencer-token');

        // Optional: allow overriding via wp-config.php
//        if (defined('AFFLUENCER_API_TOKEN') && AFFLUENCER_API_TOKEN) {
//            return hash_equals((string) AFFLUENCER_API_TOKEN, $token);
//        }

        $saved = (string) get_option(Activator::OPTION_TOKEN, '');
        if ($saved === '' || $token === '') return false;

        return hash_equals($saved, $token);
    }
}
