<?php
namespace AffluencerAAM\Rest;

use AffluencerAAM\Db\CampaignRepository;
use AffluencerAAM\Services\ProductTagService;
use AffluencerAAM\Services\UrlGenerator;

class CampaignController {
    private \AffluencerAAM\Db\CampaignRepository $repo;
    private \AffluencerAAM\Services\UrlGenerator $url;
    private Auth $auth;
    private ProductTagService $tagSvc;
    private string $api_namespace = 'affluencer/v1';

    public function __construct() {
        $this->repo=new CampaignRepository();
        $this->url  = new UrlGenerator();
        $this->auth = new Auth();
        $this->tagSvc = new ProductTagService();
    }

    public function register_routes(): void {
        register_rest_route($this->api_namespace, '/campaigns/upsert', [
            'methods'  => 'POST',
            'callback' => [$this, 'upsert'],
            'permission_callback' => [$this, 'permission'],
        ]);

        register_rest_route($this->api_namespace, '/campaigns/(?P<code>[A-Za-z0-9\-_]+)/show', [
            'methods'  => 'GET',
            'callback' => [$this, 'show'],
            'permission_callback' => [$this, 'permission'],
        ]);

        // ✅ LIST (query params)
        // /wp-json/affluencer/v1/campaigns/list?campaign_type=eid&sku=SKU-001&date_from=2026-01-01&date_to=2026-01-31&page=1&per_page=20
        register_rest_route($this->api_namespace, '/campaigns/list', [
            'methods'  => 'GET',
            'callback' => [$this, 'list'],
            'permission_callback' => [$this, 'permission'],
        ]);

        // ✅ LIST (WooCommerce tag-style paths)
        // /wp-json/affluencer/v1/campaigns/list/eid
        register_rest_route($this->api_namespace, '/campaigns/list/(?P<campaign_type>[A-Za-z0-9\-_]+)', [
            'methods'  => 'GET',
            'callback' => [$this, 'list'],
            'permission_callback' => [$this, 'permission'],
        ]);

        // /wp-json/affluencer/v1/campaigns/list/eid/sku/SKU-001
        register_rest_route($this->api_namespace, '/campaigns/list/(?P<campaign_type>[A-Za-z0-9\-_]+)/sku/(?P<sku>[A-Za-z0-9\-_]+)', [
            'methods'  => 'GET',
            'callback' => [$this, 'list'],
            'permission_callback' => [$this, 'permission'],
        ]);

        // Get all products
        register_rest_route($this->api_namespace, '/products', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_products'),
            'permission_callback' => array($this, 'permission'),
            'args' => array(
                'per_page' => array(
                    'default' => 10,
                    'sanitize_callback' => 'absint',
                ),
                'page' => array(
                    'default' => 1,
                    'sanitize_callback' => 'absint',
                ),
                'status' => array(
                    'default' => 'publish',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'search' => array(
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Search products by name or description',
                ),
                'brand' => array(
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Filter by brand slug (comma-separated for multiple, e.g., "siodil,another-brand")',
                ),
                'category' => array(
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Filter by category slug (comma-separated for multiple, e.g., "skincare,makeup")',
                ),
                'concern' => array(
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Filter by concern/keyword slug (comma-separated for multiple, e.g., "anti-acne,anti-aging")',
                ),
                'skin_type' => array(
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Filter by skin type (comma-separated for multiple, e.g., "Oily,Dry,Sensitive")',
                ),
                'ingredients' => array(
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Filter by ingredients (comma-separated for multiple, e.g., "Niacinamide,Hyaluronic Acid")',
                ),
                'line_up' => array(
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Filter by ACF line_up field (comma-separated values, e.g., "lineup1,lineup2")',
                ),
            ),
        ));

        // Get single product
        register_rest_route($this->api_namespace, '/products/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product'),
            'permission_callback' => array($this, 'permission'),
            'args' => array(
                'id' => array(
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ),
            ),
        ));

        // Get product by SKU
        register_rest_route($this->api_namespace, '/products/sku/(?P<sku>[a-zA-Z0-9-_]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product_by_sku'),
            'permission_callback' => array($this, 'permission'),
        ));

        // Get product categories
        register_rest_route($this->api_namespace, '/categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_categories'),
            'permission_callback' => array($this, 'permission'),
        ));
    }

    public function permission($r): bool { return $this->auth->allowed($r); }

    public function upsert(\WP_REST_Request $request): \WP_REST_Response {
        $payload = $request->get_json_params();

        $code = isset($payload['campaign_code']) ? sanitize_text_field($payload['campaign_code']) : '';
        $type = isset($payload['campaign_type']) ? sanitize_text_field($payload['campaign_type']) : '';
        $products = (isset($payload['products']) && is_array($payload['products'])) ? $payload['products'] : [];

        if (!$code || !$type) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'campaign_code and campaign_type are required',
            ], 422);
        }

        $full_url = $this->url->campaign_url($code);

        $this->repo->upsert_campaign($code, $type, $full_url);

        $this->repo->replace_products($code, $products);

        $tagResult = $this->tagSvc->tagProductsByCampaign($code, $products);

        $obj = $this->repo->fetch_full_object($code);

        return new \WP_REST_Response([
            'success' => true,
            'data' => [
                'campaign' => $obj,
                'tagging'  => $tagResult,
            ],
        ], 200);
    }

    public function show(\WP_REST_Request $request): \WP_REST_Response {
        $code = sanitize_text_field((string) $request->get_param('code'));

        if (!$code) {
            return new \WP_REST_Response(['success' => false, 'message' => 'code required'], 422);
        }

        $obj = $this->repo->fetch_full_object($code);

        if (!$obj) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Not found'], 404);
        }

        return new \WP_REST_Response(['success' => true, 'data' => $obj], 200);
    }

    public function list($r) {
        $filters=[
            'campaign_type'=>$r->get_param('campaign_type'),
            'sku'=>$r->get_param('sku'),
            'date_from'=>$r->get_param('date_from'),
            'date_to'=>$r->get_param('date_to'),
        ];
        $page=max(1,(int)$r->get_param('page'));
        $per=min(100,max(1,(int)$r->get_param('per_page')));
        $res=$this->repo->search($filters,$page,$per);
        return ['success'=>true,'data'=>$res];
    }

    /**
     * Get all products
     */
    public function get_products($request) {

        $per_page = $request->get_param('per_page');
        $page = $request->get_param('page');
        $status = $request->get_param('status');
        $search = $request->get_param('search');
        $brand = $request->get_param('brand');
        $line_up = $request->get_param('line_up');
        $category = $request->get_param('category');
        $concern = $request->get_param('concern');
        $skin_type = $request->get_param('skin_type');
        $ingredients = $request->get_param('ingredients');

        $args = array(
            'status' => 'publish',
            'limit' => $per_page,
            'page' => $page,
        );

        // Add search filter
        if (!empty($search)) {
            $args['s'] = $search;
        }

        // Build tax_query for brand and category
        $tax_query = array();

        // Add brand filter
        if (!empty($brand)) {
            $brand_values = array_map('trim', explode(',', $brand));
            $brand_values = array_filter($brand_values);

            if (!empty($brand_values)) {
                $tax_query[] = array(
                    'taxonomy' => 'brand',
                    'field' => 'slug',
                    'terms' => $brand_values,
                    'operator' => 'IN',
                );
            }
        }

        // Add category filter
        if (!empty($category)) {
            $category_values = array_map('trim', explode(',', $category));
            $category_values = array_filter($category_values);

            if (!empty($category_values)) {
                $tax_query[] = array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => $category_values,
                    'operator' => 'IN',
                );
            }
        }

        // Add tax_query to args if there are any filters
        if (!empty($tax_query)) {
            $args['tax_query'] = $tax_query;
            // Use AND operator between different taxonomies
            if (count($tax_query) > 1) {
                $args['tax_query']['relation'] = 'AND';
            }
        }


        $products = wc_get_products($args);

        // Apply ACF field filters with OR logic
        $acf_filters = array();

        if (!empty($line_up)) {
            $line_up_values = array_map('trim', explode(',', $line_up));
            $line_up_values = array_filter($line_up_values);
            if (!empty($line_up_values)) {
                $acf_filters['line_up'] = array('type' => 'checkbox', 'values' => $line_up_values);
            }
        }


        if (!empty($skin_type)) {
            $skin_type_values = array_map('trim', explode(',', $skin_type));
            $skin_type_values = array_filter($skin_type_values);
            if (!empty($skin_type_values)) {
                $acf_filters['skin_type'] = array('type' => 'checkbox', 'values' => $skin_type_values);
            }
        }

        if (!empty($concern)) {
            $concern_values = array_map('trim', explode(',', $concern));
            $concern_values = array_filter($concern_values);
            if (!empty($concern_values)) {
                $acf_filters['concern'] = array('type' => 'checkbox', 'values' => $concern_values);
            }
        }

        if (!empty($ingredients)) {
            $ingredient_values = array_map('trim', explode(',', $ingredients));
            $ingredient_values = array_filter($ingredient_values);
            if (!empty($ingredient_values)) {
                $acf_filters['ingredient_list'] = array('type' => 'text', 'values' => $ingredient_values);
            }
        }

        // Apply ACF filters with OR logic (combine results from multiple filters)
        if (!empty($acf_filters)) {
            $products = $this->filter_by_multiple_acf_fields_or($products, $acf_filters);

        }

        // Build total query args for pagination
        $total_args = array(
            'status' => $status,
            'return' => 'ids',
            'limit' => -1,
        );

        if (!empty($search)) {
            $total_args['s'] = $search;
        }

        if (!empty($tax_query)) {
            $total_args['tax_query'] = $args['tax_query'];
        }

        $total_ids = wc_get_products($total_args);


        // Apply ACF filters to total count with OR logic
        if (!empty($acf_filters)) {
            $total_ids = $this->filter_by_multiple_acf_fields_or_ids($total_ids, $acf_filters);
        }

        $response_data = array();

        foreach ($products as $product) {
            $response_data[] = $this->format_product_data($product);
        }

        $response = rest_ensure_response($response_data);

        // Add pagination headers
        $response->header('X-Total-Count', count($total_ids));
        $response->header('X-Total-Pages', ceil(count($total_ids) / $per_page));
        $response->header('X-Current-Page', $page);

        return $response;
    }

    /**
     * Get single product
     */
    public function get_product($request) {
        $product_id = $request->get_param('id');
        $product = wc_get_product($product_id);

        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found.',
                array('status' => 404)
            );
        }

        return rest_ensure_response($this->format_product_data($product));
    }

    /**
     * Get product by SKU
     */
    public function get_product_by_sku($request) {
        $sku = $request->get_param('sku');
        $product_id = wc_get_product_id_by_sku($sku);

        if (!$product_id) {
            return new WP_Error(
                'product_not_found',
                'Product with this SKU not found.',
                array('status' => 404)
            );
        }

        $product = wc_get_product($product_id);

        return rest_ensure_response($this->format_product_data($product));
    }

    /**
     * Get product categories
     */
    public function get_categories($request) {
        $terms = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ));

        $categories = array();

        foreach ($terms as $term) {
            $thumbnail_id = get_term_meta($term->term_id, 'thumbnail_id', true);

            $categories[] = array(
                'id' => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'description' => $term->description,
                'count' => $term->count,
                'parent' => $term->parent,
                'image' => $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : null,
            );
        }

        return rest_ensure_response($categories);
    }

    /**
     * Format product data
     */
    private function format_product_data($product) {
        $data = array(
            'id' => $product->get_id(),
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'permalink' => $product->get_permalink(),
            'status' => $product->get_status(),
            'short_description' => $product->get_short_description(),
            'sku' => $product->get_sku(),
            'price' => $product->get_price(),
            'regular_price' => $product->get_regular_price(),
            'sale_price' => $product->get_sale_price(),
            'categories' => $this->get_product_categories($product),
            'brand' => $this->get_product_brand(($product)),
            'images' => $this->get_product_images($product),
        );

        // Add variation data if product is variable
        if ($product->is_type('variable')) {
            $data['variations'] = $this->get_product_variations($product);
        }

        return $data;
    }

    /**
     * Get product categories
     */
    private function get_product_categories($product) {
        $categories = array();
        $terms = get_the_terms($product->get_id(), 'product_cat');

        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $categories[] = array(
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                );
            }
        }

        return $categories;
    }

    private function get_product_brand($product) {
        $brands = array();
        $terms = get_the_terms($product->get_id(), 'brand');

        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $brands[] = array(
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                );
            }
        }

        if( count($brands) > 0 ) {
            return $brands[0];
        }

        return null;
    }

    /**
     * Get product tags
     */
    private function get_product_tags($product) {
        $tags = array();
        $terms = get_the_terms($product->get_id(), 'product_tag');

        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $tags[] = array(
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                );
            }
        }

        return $tags;
    }

    /**
     * Get product images
     */
    private function get_product_images($product) {
        $images = array();

        // Main image
        if ($product->get_image_id()) {
            $images[] = array(
                'id' => $product->get_image_id(),
                'src' => wp_get_attachment_url($product->get_image_id()),
                'name' => get_the_title($product->get_image_id()),
                'alt' => get_post_meta($product->get_image_id(), '_wp_attachment_image_alt', true),
                'position' => 0,
            );
        }

        // Gallery images
        $gallery_ids = $product->get_gallery_image_ids();
        if ($gallery_ids) {
            $position = 1;
            foreach ($gallery_ids as $image_id) {
                $images[] = array(
                    'id' => $image_id,
                    'src' => wp_get_attachment_url($image_id),
                    'name' => get_the_title($image_id),
                    'alt' => get_post_meta($image_id, '_wp_attachment_image_alt', true),
                    'position' => $position,
                );
                $position++;
            }
        }

        return $images;
    }

    /**
     * Get product attributes
     */
    private function get_product_attributes($product) {
        $attributes = array();

        foreach ($product->get_attributes() as $attribute) {
            $attributes[] = array(
                'id' => $attribute->get_id(),
                'name' => $attribute->get_name(),
                'position' => $attribute->get_position(),
                'visible' => $attribute->get_visible(),
                'variation' => $attribute->get_variation(),
                'options' => $attribute->get_options(),
            );
        }

        return $attributes;
    }

    /**
     * Filter products by ACF field with multiple values (checkbox/select)
     *
     * @param array $products List of WC_Product objects
     * @param string $field_name The ACF field name to filter by
     * @param array $filter_values Array of values to match
     * @return array Filtered products
     */
    private function filter_by_acf_field($products, $field_name, $filter_values) {
        $filtered_products = array();

        // Convert filter values to lowercase for case-insensitive comparison
        $filter_values_lower = array_map('strtolower', $filter_values);

        foreach ($products as $product) {
            $product_id = $product->get_id();
            $product_value = get_field($field_name, $product_id);

            if (empty($product_value)) {
                continue;
            }

            // Ensure it's an array
            if (!is_array($product_value)) {
                $product_value = array($product_value);
            }

            // Check if any of the product's values match any of the requested values (case-insensitive)
            $has_match = false;
            foreach ($product_value as $value) {
                if (in_array(strtolower($value), $filter_values_lower)) {
                    $has_match = true;
                    break;
                }
            }

            if ($has_match) {
                $filtered_products[] = $product;
            }
        }



        return $filtered_products;
    }

    /**
     * Filter product IDs by ACF field with multiple values (checkbox/select)
     *
     * @param array $product_ids List of product IDs
     * @param string $field_name The ACF field name to filter by
     * @param array $filter_values Array of values to match
     * @return array Filtered product IDs
     */
    private function filter_by_acf_field_ids($product_ids, $field_name, $filter_values) {
        $filtered_ids = array();

        // Convert filter values to lowercase for case-insensitive comparison
        $filter_values_lower = array_map('strtolower', $filter_values);

        foreach ($product_ids as $product_id) {
            $product_value = get_field($field_name, $product_id);

            if (empty($product_value)) {
                continue;
            }

            // Ensure it's an array
            if (!is_array($product_value)) {
                $product_value = array($product_value);
            }

            // Check if any of the product's values match any of the requested values (case-insensitive)
            $has_match = false;
            foreach ($product_value as $value) {
                if (in_array(strtolower($value), $filter_values_lower)) {
                    $has_match = true;
                    break;
                }
            }

            if ($has_match) {
                $filtered_ids[] = $product_id;
            }
        }

        return $filtered_ids;
    }

    /**
     * Filter products by ACF field with text search (WYSIWYG)
     *
     * @param array $products List of WC_Product objects
     * @param string $field_name The ACF field name to search in
     * @param array $search_values Array of values to search for
     * @return array Filtered products
     */
    private function filter_by_text_field($products, $field_name, $search_values) {
        $filtered_products = array();

        foreach ($products as $product) {
            $product_id = $product->get_id();
            $field_content = get_field($field_name, $product_id);

            if (empty($field_content)) {
                continue;
            }

            // Convert to lowercase for case-insensitive search
            $field_content_lower = strtolower($field_content);

            // Check if any of the requested values are in the field
            $has_match = false;
            foreach ($search_values as $search_value) {
                $search_lower = strtolower($search_value);
                if (stripos($field_content_lower, $search_lower) !== false) {
                    $has_match = true;
                    break;
                }
            }

            if ($has_match) {
                $filtered_products[] = $product;
            }
        }

        return $filtered_products;
    }

    /**
     * Filter product IDs by ACF field with text search (WYSIWYG)
     *
     * @param array $product_ids List of product IDs
     * @param string $field_name The ACF field name to search in
     * @param array $search_values Array of values to search for
     * @return array Filtered product IDs
     */
    private function filter_by_text_field_ids($product_ids, $field_name, $search_values) {
        $filtered_ids = array();

        foreach ($product_ids as $product_id) {
            $field_content = get_field($field_name, $product_id);

            if (empty($field_content)) {
                continue;
            }

            // Convert to lowercase for case-insensitive search
            $field_content_lower = strtolower($field_content);

            // Check if any of the requested values are in the field
            $has_match = false;
            foreach ($search_values as $search_value) {
                $search_lower = strtolower($search_value);
                if (stripos($field_content_lower, $search_lower) !== false) {
                    $has_match = true;
                    break;
                }
            }

            if ($has_match) {
                $filtered_ids[] = $product_id;
            }
        }

        return $filtered_ids;
    }

    /**
     * Get product variations
     */
    private function get_product_variations($product) {
        $variations = array();

        foreach ($product->get_children() as $variation_id) {
            $variation = wc_get_product($variation_id);

            if ($variation) {
                $variations[] = array(
                    'id' => $variation->get_id(),
                    'sku' => $variation->get_sku(),
                    'price' => $variation->get_price(),
                    'regular_price' => $variation->get_regular_price(),
                    'sale_price' => $variation->get_sale_price(),
                    'on_sale' => $variation->is_on_sale(),
                    'stock_status' => $variation->get_stock_status(),
                    'stock_quantity' => $variation->get_stock_quantity(),
                    'attributes' => $variation->get_attributes(),
                    'image' => $variation->get_image_id() ? wp_get_attachment_url($variation->get_image_id()) : null,
                );
            }
        }

        return $variations;
    }

    /**
     * Filter products by multiple ACF fields with OR logic
     * Combines results from different ACF field filters
     *
     * @param array $products List of WC_Product objects
     * @param array $acf_filters Array of filters with format: ['field_name' => ['type' => 'checkbox|text', 'values' => [...]]]
     * @return array Filtered products (union of all filter results)
     */
    private function filter_by_multiple_acf_fields_or($products, $acf_filters) {
        if (empty($acf_filters) || empty($products)) {
            return $products;
        }

        $matching_product_ids = array();

        foreach ($acf_filters as $field_name => $filter_info) {
            $field_type = $filter_info['type'];
            $field_values = $filter_info['values'];




            if ($field_type === 'text') {
                $filtered = $this->filter_by_text_field($products, $field_name, $field_values);
            } else {
                $filtered = $this->filter_by_acf_field($products, $field_name, $field_values);
            }

            foreach ($filtered as $product) {
                $matching_product_ids[$product->get_id()] = $product;
            }
        }

        return array_values($matching_product_ids);
    }

    /**
     * Filter product IDs by multiple ACF fields with OR logic
     * Combines results from different ACF field filters
     *
     * @param array $product_ids List of product IDs
     * @param array $acf_filters Array of filters with format: ['field_name' => ['type' => 'checkbox|text', 'values' => [...]]]
     * @return array Filtered product IDs (union of all filter results)
     */
    private function filter_by_multiple_acf_fields_or_ids($product_ids, $acf_filters) {
        if (empty($acf_filters) || empty($product_ids)) {
            return $product_ids;
        }

        $matching_ids = array();

        foreach ($acf_filters as $field_name => $filter_info) {
            $field_type = $filter_info['type'];
            $field_values = $filter_info['values'];

            if ($field_type === 'text') {
                $filtered = $this->filter_by_text_field_ids($product_ids, $field_name, $field_values);
            } else {
                $filtered = $this->filter_by_acf_field_ids($product_ids, $field_name, $field_values);
            }

            foreach ($filtered as $product_id) {
                $matching_ids[$product_id] = $product_id;
            }
        }

        return array_values($matching_ids);
    }

}
