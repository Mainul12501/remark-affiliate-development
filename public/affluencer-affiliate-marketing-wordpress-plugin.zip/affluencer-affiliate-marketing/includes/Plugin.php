<?php
namespace AffluencerAAM;

use AffluencerAAM\Rest\CampaignController;
use AffluencerAAM\Admin\SettingsPage;

class Plugin {
    public function boot(): void {
        (new Rewrites())->register();

        // ✅ Admin settings
        if (is_admin()) {
            (new SettingsPage())->register();
        }

        add_action('rest_api_init', function () {

            (new CampaignController())->register_routes();
        });
    }
}
