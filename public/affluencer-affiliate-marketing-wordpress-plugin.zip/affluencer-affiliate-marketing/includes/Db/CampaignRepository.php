<?php
namespace AffluencerAAM\Db;

if (!defined('ABSPATH')) exit;

class CampaignRepository {

    private string $table_campaigns;
    private string $table_pivot;

    public function __construct() {
        global $wpdb;
        $this->table_campaigns = $wpdb->prefix . 'affiliate_campaigns';
        $this->table_pivot     = $wpdb->prefix . 'affiliate_campaign_products';
    }

    public function upsert_campaign(string $code, string $type, ?string $full_url) {
        global $wpdb;

        $existing_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->table_campaigns} WHERE campaign_code = %s LIMIT 1",
            $code
        ));

        if ($existing_id) {
            $result = $wpdb->update(
                $this->table_campaigns,
                ['campaign_type' => $type, 'full_url' => $full_url],
                ['id' => (int) $existing_id],
                ['%s', '%s'],
                ['%d']
            );
        }

       $result = $wpdb->insert(
            $this->table_campaigns,
            ['campaign_code' => $code, 'campaign_type' => $type, 'full_url' => $full_url],
            ['%s', '%s', '%s']
        );

        if ($result === false) {
            error_log("[AffluencerAAM] INSERT failed: " . $wpdb->last_error);
            error_log("[AffluencerAAM] Last query: " . $wpdb->last_query);
        }

        return $result;
    }

    public function replace_products(string $campaign_code, array $products): void {
        global $wpdb;

        // Remove previous rows for campaign
        $wpdb->delete($this->table_pivot, ['campaign_code' => $campaign_code], ['%s']);

        foreach ($products as $p) {
            $product_code = isset($p['code']) ? sanitize_text_field($p['code']) : '';
            $sku          = isset($p['sku']) ? sanitize_text_field($p['sku']) : '';

            if (!$product_code || !$sku) continue;

            $wpdb->insert(
                $this->table_pivot,
                [
                    'campaign_code' => $campaign_code,
                    'code'  => $product_code,
                    'sku'           => $sku,
                ],
                ['%s', '%s', '%s']
            );
        }
    }

    public function find_campaign(string $campaign_code): ?array {
        global $wpdb;

        $campaign = $wpdb->get_row($wpdb->prepare(
            "SELECT campaign_code, campaign_type, full_url, created_at, updated_at
             FROM {$this->table_campaigns}
             WHERE campaign_code = %s
             LIMIT 1",
            $campaign_code
        ), ARRAY_A);

        return $campaign ?: null;
    }

    public function get_products(string $campaign_code): array {
        global $wpdb;

        return $wpdb->get_results($wpdb->prepare(
            "SELECT product_code, sku
             FROM {$this->table_pivot}
             WHERE campaign_code = %s
             ORDER BY id ASC",
            $campaign_code
        ), ARRAY_A) ?: [];
    }

    public function fetch_full_object(string $campaign_code): ?array {
        $campaign = $this->find_campaign($campaign_code);
        if (!$campaign) return null;

        $campaign['products'] = $this->get_products($campaign_code);
        return $campaign;
    }
}
