<?php
namespace AffluencerAAM\Db;

class Schema {

    public function create_tables(): void {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();

        // Campaigns table
        dbDelta("
            CREATE TABLE {$wpdb->prefix}affiliate_campaigns (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                campaign_code VARCHAR(64) NOT NULL,
                campaign_type VARCHAR(50) DEFAULT NULL,
                full_url TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY uq_campaign_code (campaign_code),
                KEY idx_created_at (created_at)
            ) $charset;
        ");

        // Campaign products table
        dbDelta("
            CREATE TABLE {$wpdb->prefix}affiliate_campaign_products (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                campaign_code VARCHAR(64) NOT NULL,
                code VARCHAR(64) NOT NULL,
                sku VARCHAR(64) NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_code_sku (code, sku)
            ) $charset;
        ");
    }
}
